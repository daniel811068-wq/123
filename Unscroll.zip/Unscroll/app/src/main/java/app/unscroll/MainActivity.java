package app.unscroll;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Insets;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends Activity implements SharedPreferences.OnSharedPreferenceChangeListener {

    private static final Feature[] FEATURES = Feature.values();
    private static final int[] ROW_IDS = {R.id.row_ig, R.id.row_tiktok, R.id.row_yt};
    private static final int[] SWITCH_IDS = {R.id.switch_ig, R.id.switch_tiktok, R.id.switch_yt};
    private static final int[] STATUS_IDS = {R.id.status_ig, R.id.status_tiktok, R.id.status_yt};

    private View statusDot;
    private TextView statusTitle;
    private TextView statusBody;
    private Button statusButton;
    private TextView restrictedHelp;
    private Button appInfoButton;
    private final TextView[] rowStatus = new TextView[FEATURES.length];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        applySystemBarPadding(findViewById(R.id.root));

        statusDot = findViewById(R.id.status_dot);
        statusTitle = findViewById(R.id.status_title);
        statusBody = findViewById(R.id.status_body);
        statusButton = findViewById(R.id.status_button);
        restrictedHelp = findViewById(R.id.restricted_help);
        appInfoButton = findViewById(R.id.app_info_button);

        for (int i = 0; i < FEATURES.length; i++) {
            final Feature feature = FEATURES[i];
            final Switch toggle = findViewById(SWITCH_IDS[i]);
            rowStatus[i] = findViewById(STATUS_IDS[i]);
            toggle.setChecked(Prefs.isOn(this, feature));
            toggle.setOnCheckedChangeListener((button, on) -> {
                Prefs.setOn(this, feature, on);
                refreshRows();
            });
            findViewById(ROW_IDS[i]).setOnClickListener(v -> toggle.toggle());
        }

        statusButton.setOnClickListener(v -> openAccessibilitySettings());
        appInfoButton.setOnClickListener(v -> openAppInfo());
    }

    @Override
    protected void onResume() {
        super.onResume();
        Prefs.get(this).registerOnSharedPreferenceChangeListener(this);
        refreshStatus();
        refreshRows();
    }

    @Override
    protected void onPause() {
        Prefs.get(this).unregisterOnSharedPreferenceChangeListener(this);
        super.onPause();
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences prefs, String key) {
        if (Prefs.isCountKey(key)) refreshRows();
    }

    private void refreshStatus() {
        boolean on = isServiceEnabled();
        statusDot.setBackgroundResource(on ? R.drawable.dot_on : R.drawable.dot_off);
        statusTitle.setText(on ? R.string.status_on_title : R.string.status_off_title);
        statusBody.setText(on ? R.string.status_on_body : R.string.status_off_body);
        statusButton.setVisibility(on ? View.GONE : View.VISIBLE);

        // Android 13+ blocks accessibility access for apps installed outside the Play Store
        // until the person allows "restricted settings" from App info.
        boolean showRestricted = !on && Build.VERSION.SDK_INT >= 33;
        restrictedHelp.setVisibility(showRestricted ? View.VISIBLE : View.GONE);
        appInfoButton.setVisibility(showRestricted ? View.VISIBLE : View.GONE);
    }

    private void refreshRows() {
        for (int i = 0; i < FEATURES.length; i++) {
            Feature feature = FEATURES[i];
            int count = Prefs.blockedToday(this, feature);
            String text;
            if (!Prefs.isOn(this, feature)) {
                text = getString(R.string.row_off);
            } else if (count == 0) {
                text = getString(R.string.row_none_today);
            } else {
                text = getResources().getQuantityString(R.plurals.row_blocked_today, count, count);
            }
            rowStatus[i].setText(text);
        }
    }

    private boolean isServiceEnabled() {
        String enabled = Settings.Secure.getString(
                getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabled == null) return false;
        ComponentName me = new ComponentName(this, BlockerService.class);
        TextUtils.SimpleStringSplitter splitter = new TextUtils.SimpleStringSplitter(':');
        splitter.setString(enabled);
        for (String entry : splitter) {
            if (me.equals(ComponentName.unflattenFromString(entry))) return true;
        }
        return false;
    }

    private void openAccessibilitySettings() {
        try {
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Settings.ACTION_SETTINGS));
        }
    }

    private void openAppInfo() {
        try {
            startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", getPackageName(), null)));
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Settings.ACTION_SETTINGS));
        }
    }

    /** Android 15 draws apps edge to edge; keep content clear of the status and navigation bars. */
    @SuppressWarnings("deprecation") // the getSystemWindowInset* calls only run below Android 11
    private static void applySystemBarPadding(View root) {
        final int left = root.getPaddingLeft();
        final int top = root.getPaddingTop();
        final int right = root.getPaddingRight();
        final int bottom = root.getPaddingBottom();
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int l;
            int t;
            int r;
            int b;
            if (Build.VERSION.SDK_INT >= 30) {
                Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                l = bars.left;
                t = bars.top;
                r = bars.right;
                b = bars.bottom;
            } else {
                l = insets.getSystemWindowInsetLeft();
                t = insets.getSystemWindowInsetTop();
                r = insets.getSystemWindowInsetRight();
                b = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(left + l, top + t, right + r, bottom + b);
            return insets;
        });
    }
}

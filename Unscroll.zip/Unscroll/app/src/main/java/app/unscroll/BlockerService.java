package app.unscroll;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Toast;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Watches Instagram, TikTok and YouTube and backs out of Reels, the TikTok feed and Shorts.
 *
 * How it decides:
 *  - Instagram and YouTube expose stable view ids, so those are matched by id.
 *  - TikTok obfuscates its ids, so it is matched by tab labels and the video action rail
 *    (like / comment / share buttons), which are what TalkBack reads out.
 *
 * How it exits (escalating if the screen doesn't change):
 *  1. a targeted tap (Instagram Home tab, the viewer's own back arrow, TikTok Inbox tab)
 *     or Android Back,
 *  2. Android Back,
 *  3. Android Home.
 */
public class BlockerService extends AccessibilityService {

    static final String INSTAGRAM = "com.instagram.android";
    static final String YOUTUBE = "com.google.android.youtube";
    static final Set<String> TIKTOK = new HashSet<>(Arrays.asList(
            "com.zhiliaoapp.musically",      // TikTok (most countries)
            "com.ss.android.ugc.trill",      // TikTok (some Asian markets)
            "com.zhiliaoapp.musically.go")); // TikTok Lite

    // Instagram: full-screen Reels player and its controls.
    private static final String[] IG_PLAYER_IDS = {
            "clips_viewer_view_pager", "clips_view_pager", "root_clips_layout", "clips_viewer"};
    private static final String[] IG_PLAYER_CONTROL_IDS = {"clips_ufi", "clips_viewer_action_bar"};
    private static final String[] IG_OTHER_TABS = {"feed_tab", "direct_tab", "search_tab", "profile_tab"};

    // YouTube: anything that only exists inside the Shorts player.
    private static final String[] YT_SHORTS_IDS = {
            "reel_progress_bar", "reel_recycler", "reel_watch_fragment_root",
            "reel_watch_sequence", "shorts_player"};

    // TikTok labels (English UI). Add your language's words here if your TikTok isn't in English.
    private static final String[] TT_FEED_TABS = {"home", "friends"};
    private static final String[] TT_OTHER_TABS = {"inbox", "profile", "shop"};
    private static final String[] TT_FEED_TOP_TABS = {"for you", "following"};
    private static final String TT_INBOX = "inbox";
    private static final String TT_PROFILE_MARKER = "followers";
    private static final String[][] TT_RAIL = {
            {"like"}, {"comment"}, {"share"}, {"favorite", "favourite"}};

    private static final long SCAN_DELAY_MS = 120;       // coalesce bursts of content changes
    private static final long ACTION_GAP_MS = 700;       // give the app time to react
    private static final long STRIKE_WINDOW_MS = 3000;   // repeat hits inside this escalate
    private static final long TOAST_GAP_MS = 4000;

    private enum Exit { IG_REELS_TAB, IG_VIEWER, TIKTOK_FEED_TAB, BACK }

    private static final class Hit {
        final Feature feature;
        final Exit exit;

        Hit(Feature feature, Exit exit) {
            this.feature = feature;
            this.exit = exit;
        }
    }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable scanRunnable = this::scan;
    private boolean scanQueued;

    private long lastActionAt;
    private long lastToastAt;
    private int strikes;
    private Feature lastFeature;

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        if (!isWatched(event.getPackageName().toString())) return;
        boolean newScreen = event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED;
        queueScan(newScreen ? 60 : SCAN_DELAY_MS, newScreen);
    }

    @Override
    public void onInterrupt() {
        // Nothing to stop: Unscroll gives no spoken or haptic feedback.
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(scanRunnable);
        super.onDestroy();
    }

    private static boolean isWatched(String pkg) {
        return INSTAGRAM.equals(pkg) || YOUTUBE.equals(pkg) || TIKTOK.contains(pkg);
    }

    private void queueScan(long delayMs, boolean replace) {
        if (scanQueued && !replace) return;
        handler.removeCallbacks(scanRunnable);
        scanQueued = true;
        handler.postDelayed(scanRunnable, delayMs);
    }

    private void scan() {
        scanQueued = false;
        AccessibilityNodeInfo root;
        try {
            root = getRootInActiveWindow();
        } catch (RuntimeException e) {
            return;
        }
        if (root == null || root.getPackageName() == null) return;

        Hit hit;
        try {
            hit = detect(root.getPackageName().toString(), root);
        } catch (RuntimeException e) {
            hit = null; // the screen changed under us mid-scan; the next event will rescan
        }

        long now = SystemClock.uptimeMillis();
        if (hit == null) {
            if (now - lastActionAt > ACTION_GAP_MS) strikes = 0;
            return;
        }
        if (now - lastActionAt < ACTION_GAP_MS) {
            queueScan(ACTION_GAP_MS - (now - lastActionAt) + 20, true);
            return;
        }
        if (now - lastActionAt > STRIKE_WINDOW_MS || hit.feature != lastFeature) strikes = 0;
        strikes++;
        lastFeature = hit.feature;
        lastActionAt = now;

        if (strikes == 1) {
            Prefs.recordBlock(this, hit.feature);
            if (now - lastToastAt > TOAST_GAP_MS) {
                lastToastAt = now;
                Toast.makeText(this, hit.feature.toastRes, Toast.LENGTH_SHORT).show();
            }
        }

        try {
            escape(hit, root, strikes);
        } catch (RuntimeException e) {
            performGlobalAction(GLOBAL_ACTION_BACK);
        }
        // Look again shortly, in case the app ignored us and nothing else triggers a scan.
        queueScan(ACTION_GAP_MS + 200, true);
    }

    // ---------------------------------------------------------------- detection

    private Hit detect(String pkg, AccessibilityNodeInfo root) {
        if (INSTAGRAM.equals(pkg)) {
            return Prefs.isOn(this, Feature.IG_REELS) ? detectInstagram(root) : null;
        }
        if (YOUTUBE.equals(pkg)) {
            return Prefs.isOn(this, Feature.YT_SHORTS) ? detectYouTube(root) : null;
        }
        if (TIKTOK.contains(pkg)) {
            return Prefs.isOn(this, Feature.TIKTOK_FEED) ? detectTikTok(root) : null;
        }
        return null;
    }

    private Hit detectInstagram(AccessibilityNodeInfo root) {
        // The Reels tab in the bottom bar.
        AccessibilityNodeInfo reelsTab = firstVisibleById(root, INSTAGRAM, "clips_tab");
        if (reelsTab != null && reelsTab.isSelected()
                && !anySelectedById(root, INSTAGRAM, IG_OTHER_TABS)
                && firstVisibleById(root, INSTAGRAM, "action_bar_button_back") == null) {
            return new Hit(Feature.IG_REELS, Exit.IG_REELS_TAB);
        }
        // A Reel opened full-screen from Explore, DMs, a profile or a notification.
        // Videos playing inline in the home feed keep the home action bar, so they're left alone.
        if (anyVisibleById(root, INSTAGRAM, IG_PLAYER_IDS)
                && anyVisibleById(root, INSTAGRAM, IG_PLAYER_CONTROL_IDS)
                && !anyVisibleById(root, INSTAGRAM, "main_feed_action_bar")) {
            return new Hit(Feature.IG_REELS, Exit.IG_VIEWER);
        }
        return null;
    }

    private Hit detectYouTube(AccessibilityNodeInfo root) {
        return anyVisibleById(root, YOUTUBE, YT_SHORTS_IDS)
                ? new Hit(Feature.YT_SHORTS, Exit.BACK)
                : null;
    }

    private Hit detectTikTok(AccessibilityNodeInfo root) {
        // Someone's profile (follower counts on screen) is never treated as the feed.
        if (anyVisibleWithText(root, TT_PROFILE_MARKER)) return null;

        String tab = firstSelectedLabel(root, TT_FEED_TABS);
        if (tab != null) return new Hit(Feature.TIKTOK_FEED, Exit.TIKTOK_FEED_TAB);
        if (firstSelectedLabel(root, TT_OTHER_TABS) != null) return null;

        if (firstSelectedLabel(root, TT_FEED_TOP_TABS) != null) {
            return new Hit(Feature.TIKTOK_FEED, Exit.TIKTOK_FEED_TAB);
        }
        // A full-screen video page (like / comment / share rail) reached from somewhere else.
        if (railCategories(root) >= 3) return new Hit(Feature.TIKTOK_FEED, Exit.BACK);
        return null;
    }

    // ---------------------------------------------------------------- exiting

    private void escape(Hit hit, AccessibilityNodeInfo root, int strike) {
        if (strike >= 3) {
            performGlobalAction(GLOBAL_ACTION_HOME);
            return;
        }
        if (strike == 2) {
            performGlobalAction(GLOBAL_ACTION_BACK);
            return;
        }
        boolean done = false;
        switch (hit.exit) {
            case IG_REELS_TAB:
                done = clickNodeOrAncestor(firstVisibleById(root, INSTAGRAM, "feed_tab"));
                break;
            case IG_VIEWER:
                done = clickNodeOrAncestor(firstVisibleById(root, INSTAGRAM, "action_bar_button_back"));
                break;
            case TIKTOK_FEED_TAB:
                // TikTok always opens on the feed, so send people to their Inbox instead of
                // closing the app. If the Inbox tab can't be found, leave TikTok.
                done = clickLabel(root, TT_INBOX);
                if (!done) done = performGlobalAction(GLOBAL_ACTION_HOME);
                break;
            case BACK:
            default:
                break;
        }
        if (!done) performGlobalAction(GLOBAL_ACTION_BACK);
    }

    private boolean clickLabel(AccessibilityNodeInfo root, String label) {
        List<AccessibilityNodeInfo> nodes = root.findAccessibilityNodeInfosByText(label);
        for (AccessibilityNodeInfo n : nodes) {
            if (n.isVisibleToUser() && hasLabel(n, label) && clickNodeOrAncestor(n)) return true;
        }
        for (AccessibilityNodeInfo n : nodes) {
            if (n.isVisibleToUser() && hasLabel(n, label) && tap(n)) return true;
        }
        return false;
    }

    private static boolean clickNodeOrAncestor(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo n = node;
        for (int depth = 0; n != null && depth < 5; depth++) {
            if (n.isClickable() && n.isEnabled()) {
                return n.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            }
            n = n.getParent();
        }
        return false;
    }

    private boolean tap(AccessibilityNodeInfo node) {
        Rect r = new Rect();
        node.getBoundsInScreen(r);
        if (r.isEmpty()) return false;
        Path path = new Path();
        path.moveTo(r.exactCenterX(), r.exactCenterY());
        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, 60))
                .build();
        return dispatchGesture(gesture, null, null);
    }

    // ---------------------------------------------------------------- node helpers

    private static AccessibilityNodeInfo firstVisibleById(AccessibilityNodeInfo root, String pkg, String id) {
        List<AccessibilityNodeInfo> nodes = root.findAccessibilityNodeInfosByViewId(pkg + ":id/" + id);
        for (AccessibilityNodeInfo n : nodes) {
            if (n.isVisibleToUser()) return n;
        }
        return null;
    }

    private static boolean anyVisibleById(AccessibilityNodeInfo root, String pkg, String... ids) {
        for (String id : ids) {
            if (firstVisibleById(root, pkg, id) != null) return true;
        }
        return false;
    }

    private static boolean anySelectedById(AccessibilityNodeInfo root, String pkg, String... ids) {
        for (String id : ids) {
            AccessibilityNodeInfo n = firstVisibleById(root, pkg, id);
            if (n != null && n.isSelected()) return true;
        }
        return false;
    }

    private static boolean anyVisibleWithText(AccessibilityNodeInfo root, String needle) {
        for (AccessibilityNodeInfo n : root.findAccessibilityNodeInfosByText(needle)) {
            if (n.isVisibleToUser()) return true;
        }
        return false;
    }

    /** Returns the first label whose tab (the labelled node or a parent) is selected. */
    private static String firstSelectedLabel(AccessibilityNodeInfo root, String... labels) {
        for (String label : labels) {
            for (AccessibilityNodeInfo n : root.findAccessibilityNodeInfosByText(label)) {
                if (n.isVisibleToUser() && hasLabel(n, label) && selfOrParentSelected(n)) return label;
            }
        }
        return null;
    }

    private static boolean selfOrParentSelected(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo n = node;
        for (int depth = 0; n != null && depth < 3; depth++) {
            if (n.isSelected()) return true;
            n = n.getParent();
        }
        return false;
    }

    /** Counts how many kinds of video action buttons (like, comment, share, favourite) are showing. */
    private static int railCategories(AccessibilityNodeInfo root) {
        int found = 0;
        for (String[] words : TT_RAIL) {
            if (hasDescription(root, words)) found++;
        }
        return found;
    }

    private static boolean hasDescription(AccessibilityNodeInfo root, String[] words) {
        for (String word : words) {
            for (AccessibilityNodeInfo n : root.findAccessibilityNodeInfosByText(word)) {
                CharSequence desc = n.getContentDescription();
                if (n.isVisibleToUser() && desc != null
                        && desc.toString().toLowerCase(Locale.ROOT).contains(word)) {
                    return true;
                }
            }
        }
        return false;
    }

    private static boolean hasLabel(AccessibilityNodeInfo n, String label) {
        return label.equals(normalize(n.getText())) || label.equals(normalize(n.getContentDescription()));
    }

    /** "  Home, tab 1 of 5 " -> "home" */
    private static String normalize(CharSequence cs) {
        if (cs == null) return null;
        String s = cs.toString().trim().toLowerCase(Locale.ROOT);
        int comma = s.indexOf(',');
        if (comma > 0) s = s.substring(0, comma);
        return s.replaceAll("\\s+", " ").trim();
    }
}

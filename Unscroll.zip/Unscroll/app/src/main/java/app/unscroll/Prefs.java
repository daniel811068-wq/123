package app.unscroll;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** On/off switches and the "blocked today" counters, stored on the phone only. */
final class Prefs {
    static final String FILE = "unscroll";
    private static final String DAY = "count_day";

    private Prefs() {}

    static SharedPreferences get(Context context) {
        return context.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    static boolean isOn(Context context, Feature feature) {
        return get(context).getBoolean(feature.key, true);
    }

    static void setOn(Context context, Feature feature, boolean on) {
        get(context).edit().putBoolean(feature.key, on).apply();
    }

    static int blockedToday(Context context, Feature feature) {
        SharedPreferences p = get(context);
        if (!today().equals(p.getString(DAY, ""))) return 0;
        return p.getInt(countKey(feature), 0);
    }

    static void recordBlock(Context context, Feature feature) {
        SharedPreferences p = get(context);
        SharedPreferences.Editor e = p.edit();
        String today = today();
        if (!today.equals(p.getString(DAY, ""))) {
            for (Feature f : Feature.values()) e.putInt(countKey(f), 0);
            e.putString(DAY, today);
            e.putInt(countKey(feature), 1);
        } else {
            e.putInt(countKey(feature), p.getInt(countKey(feature), 0) + 1);
        }
        e.apply();
    }

    static boolean isCountKey(String key) {
        return key != null && (key.startsWith("count_"));
    }

    private static String countKey(Feature f) {
        return "count_" + f.key;
    }

    private static String today() {
        return new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date());
    }
}

package app.unscroll;

/** The feeds Unscroll can switch off. Order matches the rows on the main screen. */
enum Feature {
    IG_REELS("block_ig_reels", R.string.toast_ig_reels),
    TIKTOK_FEED("block_tiktok_feed", R.string.toast_tiktok_feed),
    YT_SHORTS("block_yt_shorts", R.string.toast_yt_shorts);

    final String key;
    final int toastRes;

    Feature(String key, int toastRes) {
        this.key = key;
        this.toastRes = toastRes;
    }
}

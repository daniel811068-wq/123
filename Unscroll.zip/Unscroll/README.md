# Unscroll

An Android app with on/off switches for:

- **Instagram Reels**: the Reels tab, plus Reels opened full-screen from Explore, DMs, profiles or notifications. Your home feed, Stories, DMs and search keep working.
- **TikTok feed**: For You, Following and Friends. You're sent to your Inbox instead, so messages still work.
- **YouTube Shorts**: the Shorts tab and any Short opened full-screen. Normal videos keep working.

When a switched-off feed opens, Unscroll taps back (or the Home/Inbox tab) for you and shows a small "switched off" message. The app also counts how many times it stepped in today.

It has no internet permission. It only receives screen information from Instagram, TikTok and YouTube, and nothing leaves the phone.

---

## 1. Get the app onto your phone

### Option A: you have a computer (Windows, Mac or Linux)

1. Install **Android Studio** (free) from developer.android.com/studio.
2. Unzip `Unscroll.zip`, then in Android Studio choose **Open** and pick the `Unscroll` folder. Let it finish syncing (it downloads what it needs the first time).
3. On your phone: **Settings → About phone →** tap **Build number** 7 times. Then **Settings → System → Developer options →** turn on **USB debugging**.
4. Plug the phone in, accept the "Allow USB debugging?" prompt, and press the green **▶ Run** button in Android Studio.

(Or use **Build → Build App Bundle(s) / APK(s) → Build APK(s)** and copy `app/build/outputs/apk/debug/app-debug.apk` to your phone.)

### Option B: phone only (GitHub builds it for you, free)

1. Make a free account at github.com and create a new repository (tick **Add a README file**).
2. In the repository: **Add file → Upload files →** choose `Unscroll.zip` → **Commit changes**.
3. **Add file → Create new file**. Name it exactly `.github/workflows/build.yml`, paste in the contents of `build.yml` (it's in this project at `.github/workflows/build.yml`), and **Commit changes**.
4. Open the **Actions** tab and wait for "Build APK" to get a green tick (about 3–5 minutes).
5. Go to the repository's **Releases** (on the main page) and tap **Unscroll.apk**. Open the download and allow installs from your browser when Android asks.

Every later upload builds a new release; it installs over the old one.

## 2. Switch it on (once)

1. Open **Unscroll** and tap **Open Accessibility settings**.
2. Tap **Unscroll** (it may be under *Installed apps* or *Downloaded apps*), turn it on, and accept.
3. **If the switch is greyed out or says "Restricted setting"** (Android 13 and newer do this for apps not from the Play Store): go to **Settings → Apps → Unscroll**, tap **⋮** in the top corner, choose **Allow restricted settings**, then repeat step 2. The app has an **Open App info** button that takes you straight there.

Back in Unscroll you'll see **Unscroll is on**. Flip any of the three switches whenever you like.

**Samsung / Xiaomi / some other phones** may stop background helpers to save battery. If it stops working after a while: **Settings → Apps → Unscroll → Battery → Unrestricted**.

---

## Good to know

- **App updates can break detection.** Instagram, TikTok and YouTube change their screens now and then. Everything Unscroll looks for is listed at the top of `app/src/main/java/app/unscroll/BlockerService.java`, so it's quick to adjust.
- **TikTok is matched by its English labels** ("Home", "Inbox", "For You", "Following"). If your TikTok is in another language, add your words to the `TT_...` lists in `BlockerService.java`.
- **TikTok always opens on the feed**, so with the feed switched off it opens on your Inbox.
- It's a speed bump, not a lock: you can switch it off in the app or in Accessibility settings at any time.

## How it decides (for tinkering)

| App | Blocked when | What it does |
|---|---|---|
| Instagram | `clips_tab` is the selected tab, or the full-screen Reels player (`clips_viewer…` + its `clips_ufi` controls) is showing without the home feed's top bar | Taps the Home tab, or the player's back arrow |
| TikTok | The **Home** or **Friends** tab is selected, or **For You / Following** is selected, or a full-screen video's like/comment/share buttons are showing. Profiles are never blocked | Taps **Inbox** (or Back for a single video) |
| YouTube | Any Shorts-player view (`reel_recycler`, `reel_progress_bar`, `shorts_player`, …) is visible | Back |

If a screen stays put, it tries Back, then goes to the home screen.
